﻿using ReporteParametrizado.Reports;
using SQLiteManager;
using System;
using System.Windows.Forms;

namespace ReporteParametrizado.Listas
{
    public partial class FormEntityList : Form
    {
        public string RecordType { get; set; }
        private SQLiteClient sqliteClient { get; set; }

        public FormEntityList()
        {
            InitializeComponent();
        }

        private void FormEntityList_Load(object sender, EventArgs e)
        {
            string databasePath = Properties.Settings.Default.DatabasePath;

            this.sqliteClient = new SQLiteClient(databasePath);

            RefreshDataGridView();
        }

        private void RefreshDataGridView()
        {
            string filters = String.Empty;

            if (!String.IsNullOrEmpty(TxtBuscar.Text))
            {
                string criteria = TxtBuscar.Text;
                filters = $" AND (name Like '{criteria}%' OR " +
                    $"email Like '{criteria}%' OR " +
                    $"phone Like '{criteria}%' OR " +
                    $"address Like '{criteria}%' OR " +
                    $"city Like '{criteria}%' OR " +
                    $"state Like '{criteria}%' OR " +
                    $"zip Like '{criteria}%')";
            }

            string sql = $"SELECT * FROM entity WHERE type='{this.RecordType}'{filters};";
            GrdViewList.DataSource = this.sqliteClient.ExecuteQuery(sql);
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }

        private void BtnTodo_Click(object sender, EventArgs e)
        {
            TxtBuscar.Text = String.Empty;
            RefreshDataGridView();
        }

        private void BtnCrear_Click(object sender, EventArgs e)
        {
            FormEntity formEntity = new FormEntity()
            {
                RecordType = this.RecordType,
                RecordId = -1,
                Mode = "New"
            };

            formEntity.ShowDialog();

            RefreshDataGridView();
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            int id = GetIdFromSelectedRow();

            if (id != -1)
            {
                FormEntity formEntity = new FormEntity()
                {
                    RecordType = this.RecordType,
                    RecordId = id,
                    Mode = "Edit"
                };

                formEntity.ShowDialog();

                RefreshDataGridView();
            }
        }

        private int GetIdFromSelectedRow()
        {
            int id = -1;

            if (GrdViewList.RowCount > 0)
                id = Int32.TryParse(GrdViewList.CurrentRow.Cells["Id"].Value.ToString(), out Int32 entityID) ? entityID : -1;

            return id;
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            int id = GetIdFromSelectedRow();

            if (id != -1)
            {
                DialogResult result = MessageBox.Show("¿Seguro que quieres borrar el registro seleccionado?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    this.sqliteClient.ExecuteNonQuery($"DELETE FROM entity WHERE id={id};");
                    RefreshDataGridView();
                }
            }
        }

        private void BtnExportar_Click(object sender, EventArgs e)
        {

        }

        private void BtnImprimir_Click(object sender, EventArgs e)
        {
            FormReportViewer formReportViewer = new FormReportViewer()
            {
                RecordType = this.RecordType
            };

            formReportViewer.Show();
        }
    }
}
